# z/OS Agent

## Overview

The IBM Agents for z/OS configuration agent can take queries about the configuration of your z/OS systems, such as how to enable SMF tracing or what libraries are currently listed in LNKLST.

## Agent Capabilities

| Agent Capability | Description |
|------------------|-------------|
| z/OS System Interaction | Interact with IBM z/OS systems through z/os REST APIs |
| Dynamic Tool Loading | Leverage MCP for dynamic loading of tools and prompts |
| AI-Powered Automation | Use LangGraph-based AI to automate z/OS operations |

## Prerequisites

Ensure the following:

- watsonx Assistant for Z is installed
- z/os is properly configured and accessible
- You have the necessary credentials and permissions to access z/os APIs

## Install the z/os Agent

### Step 1: Configure Global Shared Variables

Before configuring the z/os Agent, you must set up shared variables that are common across all agents. These are defined in the `global.secrets` section of the [values.yaml](../../wxa4z-agent-suite/values.yaml) file.

Open the `wxa4z-agent-suite/values.yaml` file and configure the following under `global.secrets.data`:

```yaml
global:
  secrets:
    name: wxa4z-watsonx-credentials
    data:
      ORCHESTRATE_ENV_TYPE: "cpd"  # Set to "cpd" for on-prem or "ibm_iam" for IBM Cloud
      WATSONX_API_KEY: "<your-watsonx-api-key>"  # CPD API key (on-prem) or IBM Cloud IAM API key
      ORCHESTRATE_ENV_URL: "<your-wxo-url>"  # watsonx Orchestrate service instance URL
      CPD_USERNAME: "<your-cpd-username>"  # Required for on-prem CPD deployments
      WATSONX_DEPLOYMENT_SPACE_ID: "<your-deployment-space-id>"  # Watsonx deployment space ID
      WATSONX_ML_URL: "<your-watsonx-ml-url>"  # CPD instance FQDN for on-prem
```

### Step 2: Configure Image Pull Secret

In the same `values.yaml` file, configure the registry credentials under `global.registry`:

```yaml
global:
  registry:
    name: wxa4z-image-pull-secret
    createSecret: true  # Set to true to create the secret automatically
    server: icr.io
    username: iamapikey
    entitlementKey: "<your-entitlement-key>"  # Your watsonx Assistant for Z entitlement key
```

### Step 3: Configure z/os Agent-Specific Settings

Scroll down to the `zos-agent` section in the `values.yaml` file and configure the following:

#### 3.1 Enable the Agent

```yaml
zos-agent:
  enabled: true  # Set to true to enable the z/os Agent
```

#### 3.2 Configure Environment Variables

```yaml
  env:
    DEPLOYMENT_TYPE: "cloud"  # Set to "cloud" for IBM Cloud or "on-prem" for CPD
    ORCHESTRATE_ENV_NAME: "wxo-live-instance"  # Your watsonx Orchestrate environment name
    WATSONX_DEPLOYMENT_SPACE_ID: "<your-deployment-space-id>"  # Same as global setting
    WATSONX_MODEL_ID: "ibm/granite-3-8b-instruct"  # LLM model to use
    WATSONX_ML_URL: "<your-watsonx-ml-url>"  # Same as global setting
```

#### 3.3 Configure Agent-Specific Secrets

```yaml
  secrets:
    name: zos-icr-secrets
    data:
      ORCHESTRATE_ENV_TYPE: "cpd"  # Same as global setting
      WRAPPER_USERNAME: "<opensearch-username>"  # Username for OpenSearch wrapper
      WRAPPER_PASSWORD: "<opensearch-password>"  # Password for OpenSearch wrapper
      CPD_USERNAME: "<your-cpd-username>"  # Same as global setting
      WATSONX_API_KEY: "<your-watsonx-api-key>"  # Same as global setting
      ORCHESTRATE_ENV_URL: "<your-wxo-url>"  # Same as global setting
      AGENT_API_KEY: "<agent-api-key>"  # API key for agent authentication
      AGENT_AUTH_TOKEN: "<agent-auth-token>"  # Authentication token for the agent
```

#### 3.4 Configure Image Registry (Agent-Specific)

```yaml
  registry:
    name: zos-agent-image-pull-secret
    createSecret: true
    server: icr.io
    username: iamapikey
    entitlementKey: "<your-entitlement-key>"  # Your watsonx Assistant for Z entitlement key
```

### Install or Upgrade the wxa4z-agent-suite

> **Note**: If you're installing multiple agents, you can configure the [values.yaml](../../wxa4z-agent-suite/values.yaml) file for all the agents you wish to install. Once the file is updated, run the command below to install them all at once.

Use the following command to install or upgrade the wxa4z-agent-suite:

```bash
helm upgrade --install wxa4z-agent-suite \
  ./wxa4z-agent-suite \
  -n <wxa4z-namespace> \
  -f <path_to>/values.yaml --wait
```

Replace `<wxa4z-namespace>` with your target namespace and `<path_to>` with the path to your values.yaml file.

## Deploy the Agent

1. Log in to watsonx Orchestrate.
2. From the main menu, navigate to **Build** > **Agent Builder**.
3. Select the **z/os Agent** tile.
4. In the AI Assistant window, enter a query to confirm that the response aligns with your expectations.
5. Click **Deploy** to activate the agent and make it available in the live environment.

## Test Your Agent

After deployment, the agent becomes active and is available for selection in the live environment.

1. Log in to watsonx Orchestrate.
2. From the main menu, click **Chat**.
3. Choose your agent from the list.
4. Enter your queries using the AI Assistant.
   
   For example:
   - "Show me the status of my z/OS systems"
   - "List all active jobs on the mainframe"
   - "What is the current CPU utilization?"

   Responses are displayed either in a tabular format or as a sentence, depending on the context.

5. Verify that the responses returned by the AI Assistant are accurate.